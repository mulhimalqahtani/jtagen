//
//  customMywalletCTableViewCell.swift
//  qrcode
//
//  Created by Mulhim Alqahtani on 2/21/19.
//  Copyright © 2019 Mulhim Alqahtani. All rights reserved.
//

import Foundation
import UIKit
class customMywalletCell: UITableViewCell{
    
    
    @IBOutlet weak var name: UILabel!
    
    
    
    
    @IBOutlet weak var phoneNumber: UILabel!
    @IBOutlet weak var jobTittle: UILabel!
    @IBOutlet weak var email: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    
    
}
